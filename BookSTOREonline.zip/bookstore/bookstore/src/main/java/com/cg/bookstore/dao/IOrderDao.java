package com.cg.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.bookstore.beans.Order;

@Repository
public interface IOrderDao extends JpaRepository<Order, Integer>{

}
