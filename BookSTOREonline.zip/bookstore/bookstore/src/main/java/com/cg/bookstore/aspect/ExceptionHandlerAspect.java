package com.cg.bookstore.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.bookstore.exceptions.BookDetailsNotFoundException;
import com.cg.customresponse.CustomResponse;
@ControllerAdvice
public class ExceptionHandlerAspect {
	@ExceptionHandler(BookDetailsNotFoundException.class)
	public ResponseEntity<CustomResponse>handleAssociateDetailsNotfoundException(Exception e){
		CustomResponse response=new CustomResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
}
