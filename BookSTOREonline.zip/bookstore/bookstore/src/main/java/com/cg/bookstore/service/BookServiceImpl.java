package com.cg.bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.bookstore.beans.Book;
import com.cg.bookstore.dao.BookDAO;
import com.cg.bookstore.exceptions.BookDetailsNotFoundException;

@Component("bookService")
public class BookServiceImpl implements BookService{
	@Autowired
	BookDAO bookDao;

	@Override
	public Book acceptBookDetails(Book book) {
		book=bookDao.save(book);
		return book;	}

	@Override
	public Book getBookDetails(int bookId) throws BookDetailsNotFoundException {
		return bookDao.findById(bookId).orElseThrow(()->new BookDetailsNotFoundException("Book not found: " +bookId));
	}

	@Override
	public List<Book> getAllBookDetails() {
		return bookDao.findAll();
	}
	

}
